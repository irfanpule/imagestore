#!/usr/bin/env python
# vim:fileencoding=utf-8
